#################################################
# Store Library Version
##################################################
import os.path

from poodle.version import __version__