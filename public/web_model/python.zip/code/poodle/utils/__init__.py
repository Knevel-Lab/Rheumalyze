#from poodle.utils.tsne import *  # parametric tsne
from poodle.utils.projection import * # projecting on product space